# Guion de sustentación (Postman)

## Escenario inicial
1. Iniciar la API y autenticar `admin/admin123`.
2. Ejecutar GET `/api/buyers`: mostrar los tres compradores distintos.
3. Ejecutar GET `/api/products`: mostrar seis productos, su tipo y vendedor.
4. Ejecutar GET `/api/inventory/1` y `/api/inventory/2` para registrar el stock inicial.

## Comprador buyer1
5. Intentar POST `/api/cart/items` con `{"productId":1,"quantity":99}`. Debe responder 400 y no alterar stock ni carrito.
6. Agregar 1 unidad de producto 1, GET carrito; agregar 1 unidad de producto 2, GET carrito; agregar producto 4 digital, GET carrito; agregar producto 5 digital, GET carrito.
7. Mostrar cuatro líneas (dos físicas y dos digitales) en GET `/api/cart`.
8. POST `/api/checkout`; registrar el `id` del pedido y el ID de línea de Portátil Nexus 14. GET pedido y stock para probar persistencia y descuento.

## Operador logístico
9. Cambiar credenciales a `logistics/log123`. POST despacho; GET envío. POST entrega; GET envío.

## Devolución y reembolso
10. Volver a `buyer1/buyer123`. POST devolución del `orderLineId` correspondiente al portátil, cantidad 1.
11. Con `admin/admin123`, GET devoluciones; POST aprobar devolución; GET inventario del portátil; GET pedido. Comparar que solo el portátil esté `RETURNED`, el mouse permanezca `PURCHASED` y los dos digitales permanezcan `DIGITAL_DELIVERED`.
12. POST procesar reembolso; GET devoluciones y comprobar `status=REFUNDED` y `refundAmount` igual al valor del portátil devuelto.

## Reportes y control de acceso
13. Con seller1, GET `/api/reports/dashboard`: debe ver solo productos, ventas y movimientos de seller1. Repetir seller2.
14. Con supervisor, GET dashboard para la vista consolidada.
15. Ejecutar las pruebas negativas de la colección: buyer creando producto, buyer consultando compradores, seller despachando pedido, buyer aprobando devolución y buyer consultando reportes. Cada una debe devolver 403.

## Persistencia final
16. Guardar los IDs de pedido y devolución. Detener la aplicación sin borrar `data/`.
17. Iniciar de nuevo. Ejecutar GET pedido, GET devoluciones, GET inventario y reportes con los mismos IDs. Comparar estados, cantidades, total y movimientos con las respuestas guardadas antes del reinicio.
