package com.nexusmarket.demo.repo;
import com.nexusmarket.demo.model.Buyer;import org.springframework.data.jpa.repository.JpaRepository;import java.util.*;
public interface BuyerRepository extends JpaRepository<Buyer,Long> {}
