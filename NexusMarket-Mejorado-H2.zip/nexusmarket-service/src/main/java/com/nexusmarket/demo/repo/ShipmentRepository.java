package com.nexusmarket.demo.repo;
import com.nexusmarket.demo.model.Shipment;import org.springframework.data.jpa.repository.JpaRepository;import java.util.*;
public interface ShipmentRepository extends JpaRepository<Shipment,Long> {}
