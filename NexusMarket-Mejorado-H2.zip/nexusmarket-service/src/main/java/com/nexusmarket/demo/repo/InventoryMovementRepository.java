package com.nexusmarket.demo.repo;
import com.nexusmarket.demo.model.InventoryMovement;import org.springframework.data.jpa.repository.JpaRepository;import java.util.*;
public interface InventoryMovementRepository extends JpaRepository<InventoryMovement,Long> {}
