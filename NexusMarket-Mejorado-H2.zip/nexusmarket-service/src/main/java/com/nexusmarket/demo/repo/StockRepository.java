package com.nexusmarket.demo.repo;
import com.nexusmarket.demo.model.Stock;import org.springframework.data.jpa.repository.JpaRepository;import java.util.*;
public interface StockRepository extends JpaRepository<Stock,Long> {}
