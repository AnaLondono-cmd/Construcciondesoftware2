package com.nexusmarket.demo.model;
import jakarta.persistence.*;
@Entity @Table(name="demo_cart_lines",uniqueConstraints=@UniqueConstraint(columnNames={"buyer_id","product_id"})) public class CartLine {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) public Buyer buyer;
 @ManyToOne(optional=false) public Product product;
 public int quantity;
 public CartLine(){} public CartLine(Buyer b,Product p,int q){buyer=b;product=p;quantity=q;}
}
