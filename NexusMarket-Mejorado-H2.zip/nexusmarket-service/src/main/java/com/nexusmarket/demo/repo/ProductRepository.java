package com.nexusmarket.demo.repo;
import com.nexusmarket.demo.model.Product;import org.springframework.data.jpa.repository.JpaRepository;import java.util.*;
public interface ProductRepository extends JpaRepository<Product,Long> {}
