package com.nexusmarket.demo.repo;
import com.nexusmarket.demo.model.Purchase;import org.springframework.data.jpa.repository.JpaRepository;import java.util.*;
public interface PurchaseRepository extends JpaRepository<Purchase,Long> {}
