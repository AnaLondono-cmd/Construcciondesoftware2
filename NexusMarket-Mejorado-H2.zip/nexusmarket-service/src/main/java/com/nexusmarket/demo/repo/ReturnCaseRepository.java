package com.nexusmarket.demo.repo;
import com.nexusmarket.demo.model.ReturnCase;import org.springframework.data.jpa.repository.JpaRepository;import java.util.*;
public interface ReturnCaseRepository extends JpaRepository<ReturnCase,Long> {}
