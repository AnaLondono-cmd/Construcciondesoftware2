package com.nexusmarket.demo.model;
import jakarta.persistence.*;import com.fasterxml.jackson.annotation.JsonIgnore;import java.math.BigDecimal;
@Entity @Table(name="demo_purchase_lines") public class PurchaseLine {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @JsonIgnore @ManyToOne(optional=false) public Purchase purchase;
 @ManyToOne(optional=false) public Product product;
 @ManyToOne(optional=false) public Seller seller;
 public int quantity; public int returnedQuantity=0;
 @Column(nullable=false,precision=12,scale=2) public BigDecimal unitPrice;
 @Column(nullable=false,precision=12,scale=2) public BigDecimal lineTotal;
 public String status="PURCHASED";
 public PurchaseLine(){}
}
