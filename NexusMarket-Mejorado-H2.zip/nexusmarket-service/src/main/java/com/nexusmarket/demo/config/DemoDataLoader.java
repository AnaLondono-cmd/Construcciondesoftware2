package com.nexusmarket.demo.config;
import com.nexusmarket.demo.model.*;import com.nexusmarket.demo.repo.*;import org.springframework.boot.CommandLineRunner;import org.springframework.context.annotation.Bean;import org.springframework.context.annotation.Configuration;import java.math.BigDecimal;
@Configuration public class DemoDataLoader {
 @Bean CommandLineRunner seed(BuyerRepository buyers,SellerRepository sellers,ProductRepository products,StockRepository stocks){return args->{
  if(buyers.count()>0)return;
  Buyer b1=buyers.save(new Buyer("buyer1","Laura Gómez","laura@nexus.test","Calle 10 #20-30, Medellín"));buyers.save(new Buyer("buyer2","Carlos Ruiz","carlos@nexus.test","Carrera 40 #12-10, Medellín"));buyers.save(new Buyer("buyer3","María Torres","maria@nexus.test","Calle 50 #60-20, Medellín"));
  Seller s1=sellers.save(new Seller("seller1","TecnoFísicos S.A.S."));Seller s2=sellers.save(new Seller("seller2","DigitalHub Colombia"));
  add(products,stocks,"Portátil Nexus 14","PHYSICAL","2500000",s1,8);add(products,stocks,"Mouse inalámbrico","PHYSICAL","85000",s1,12);add(products,stocks,"Teclado mecánico","PHYSICAL","210000",s1,6);
  add(products,stocks,"Licencia Office","DIGITAL","180000",s2,0);add(products,stocks,"Curso Java","DIGITAL","95000",s2,0);add(products,stocks,"Antivirus 1 año","DIGITAL","70000",s2,0);
 };}
 private void add(ProductRepository p,StockRepository s,String n,String t,String price,Seller seller,int qty){Product x=p.save(new Product(n,t,new BigDecimal(price),seller));s.save(new Stock(x,qty));}
}
