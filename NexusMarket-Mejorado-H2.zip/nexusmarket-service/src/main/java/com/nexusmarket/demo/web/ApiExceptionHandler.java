package com.nexusmarket.demo.web;
import org.springframework.http.*;import org.springframework.web.bind.annotation.*;import org.springframework.security.access.AccessDeniedException;import java.util.*;
@RestControllerAdvice public class ApiExceptionHandler {
 @ExceptionHandler(NoSuchElementException.class) ResponseEntity<?> notFound(Exception e){return ResponseEntity.status(404).body(Map.of("error","NOT_FOUND","message",e.getMessage()));}
 @ExceptionHandler({IllegalArgumentException.class}) ResponseEntity<?> badRequest(Exception e){return ResponseEntity.badRequest().body(Map.of("error","BUSINESS_RULE_VIOLATION","message",e.getMessage()));}
 @ExceptionHandler(AccessDeniedException.class) ResponseEntity<?> forbidden(Exception e){return ResponseEntity.status(403).body(Map.of("error","FORBIDDEN","message",e.getMessage()));}
 @ExceptionHandler(Exception.class) ResponseEntity<?> general(Exception e){return ResponseEntity.status(500).body(Map.of("error","INTERNAL_ERROR","message",Objects.toString(e.getMessage(),"Error interno")));}
}
