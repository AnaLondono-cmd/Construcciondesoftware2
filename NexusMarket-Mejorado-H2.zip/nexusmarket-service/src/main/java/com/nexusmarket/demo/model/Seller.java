package com.nexusmarket.demo.model;
import jakarta.persistence.*;
@Entity @Table(name="demo_sellers") public class Seller {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(nullable=false,unique=true) public String username;
 @Column(nullable=false) public String businessName;
 public String status="ACTIVE";
 public Seller(){} public Seller(String u,String n){username=u;businessName=n;}
}
