package com.nexusmarket.demo.repo;
import com.nexusmarket.demo.model.PurchaseLine;import org.springframework.data.jpa.repository.JpaRepository;import java.util.*;
public interface PurchaseLineRepository extends JpaRepository<PurchaseLine,Long> {}
