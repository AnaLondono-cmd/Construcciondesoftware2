package com.nexusmarket.demo.model;
import jakarta.persistence.*;
@Entity @Table(name="demo_stock",uniqueConstraints=@UniqueConstraint(columnNames={"product_id"})) public class Stock {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @OneToOne(optional=false) public Product product;
 @Version public Long version;
 public int available;
 public int reserved;
 public Stock(){} public Stock(Product p,int a){product=p;available=a;}
}
