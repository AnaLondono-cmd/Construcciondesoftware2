package com.nexusmarket.demo.config;
import org.springframework.context.annotation.*;import org.springframework.security.config.Customizer;import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;import org.springframework.security.config.annotation.web.builders.HttpSecurity;import org.springframework.security.core.userdetails.User;import org.springframework.security.core.userdetails.UserDetailsService;import org.springframework.security.provisioning.InMemoryUserDetailsManager;import org.springframework.security.crypto.password.NoOpPasswordEncoder;import org.springframework.security.crypto.password.PasswordEncoder;import org.springframework.security.web.SecurityFilterChain;
@Configuration @EnableMethodSecurity
@SuppressWarnings("deprecation") public class SecurityConfig {
 @Bean PasswordEncoder passwordEncoder(){return NoOpPasswordEncoder.getInstance();}
 @Bean UserDetailsService userDetailsService(){return new InMemoryUserDetailsManager(
  User.withUsername("admin").password("admin123").roles("ADMIN").build(),
  User.withUsername("buyer1").password("buyer123").roles("BUYER").build(),User.withUsername("buyer2").password("buyer123").roles("BUYER").build(),User.withUsername("buyer3").password("buyer123").roles("BUYER").build(),
  User.withUsername("seller1").password("seller123").roles("SELLER").build(),User.withUsername("seller2").password("seller123").roles("SELLER").build(),
  User.withUsername("logistics").password("log123").roles("LOGISTICS_OPERATOR").build(),User.withUsername("supervisor").password("super123").roles("SUPERVISOR").build());}
 @Bean SecurityFilterChain filterChain(HttpSecurity http)throws Exception{return http.csrf(csrf->csrf.disable()).authorizeHttpRequests(a->a.requestMatchers("/h2-console/**").hasRole("ADMIN").anyRequest().authenticated()).httpBasic(Customizer.withDefaults()).headers(h->h.frameOptions(f->f.sameOrigin())).build();}
}
