package com.nexusmarket.demo.repo;
import com.nexusmarket.demo.model.Seller;import org.springframework.data.jpa.repository.JpaRepository;import java.util.*;
public interface SellerRepository extends JpaRepository<Seller,Long> {}
