package com.nexusmarket.demo.repo;
import com.nexusmarket.demo.model.CartLine;import org.springframework.data.jpa.repository.JpaRepository;import java.util.*;
public interface CartLineRepository extends JpaRepository<CartLine,Long> {}
