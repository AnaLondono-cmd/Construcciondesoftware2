package com.centralcity.alchemy.application.service;

import java.util.List;

import com.centralcity.alchemy.application.port.in.ProcessAccumulatedUseCase;
import com.centralcity.alchemy.application.port.in.QueryReadingsUseCase;
import com.centralcity.alchemy.application.port.out.DeviceReadingRepository;
import com.centralcity.alchemy.domain.exception.DeviceReadingNotFoundException;
import com.centralcity.alchemy.domain.model.AnalysisResult;
import com.centralcity.alchemy.domain.model.DeviceReading;
import com.centralcity.alchemy.domain.model.SurveillanceDevice;
import com.centralcity.alchemy.domain.service.SignalAnalyzer;

public class ReadingQueryService implements QueryReadingsUseCase, ProcessAccumulatedUseCase {

    private final DeviceReadingRepository repository;
    private final SignalAnalyzer analyzer;

    public ReadingQueryService(DeviceReadingRepository repository, SignalAnalyzer analyzer) {
        this.repository = repository;
        this.analyzer = analyzer;
    }

    @Override
    public List<DeviceReading> findAll() {
        return repository.findAll();
    }

    @Override
    public DeviceReading findByDevice(String deviceCode) {
        SurveillanceDevice device = SurveillanceDevice.fromCode(deviceCode);
        return repository.findByDevice(device).orElseThrow(() -> new DeviceReadingNotFoundException(device.code()));
    }

    @Override
    public AnalysisResult process() {
        return analyzer.analyze(repository.findAll());
    }
}
