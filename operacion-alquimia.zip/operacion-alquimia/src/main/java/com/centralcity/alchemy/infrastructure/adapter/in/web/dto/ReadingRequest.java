package com.centralcity.alchemy.infrastructure.adapter.in.web.dto;

import java.util.List;

/** Cuerpo de POST /readings y de cada elemento de POST /analysis. */
public record ReadingRequest(String device, Double distance, List<String> message) {
}
