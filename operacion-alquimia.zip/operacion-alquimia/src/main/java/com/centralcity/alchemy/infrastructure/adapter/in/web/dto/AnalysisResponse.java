package com.centralcity.alchemy.infrastructure.adapter.in.web.dto;

import com.centralcity.alchemy.domain.model.AnalysisResult;

public record AnalysisResponse(PositionResponse position, String message) {
    public record PositionResponse(double x, double y) {
    }

    public static AnalysisResponse from(AnalysisResult r) {
        return new AnalysisResponse(new PositionResponse(r.position().x(), r.position().y()), r.message());
    }
}
