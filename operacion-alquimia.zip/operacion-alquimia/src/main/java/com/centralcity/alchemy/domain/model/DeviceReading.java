package com.centralcity.alchemy.domain.model;

import java.util.Objects;

import com.centralcity.alchemy.domain.exception.InvalidDataException;

/** Información registrada de un dispositivo. Inmutable: los cambios producen una nueva instancia. */
public record DeviceReading(SurveillanceDevice device, Distance distance, MessageFragment fragment) {
    public DeviceReading {
        if (device == null || distance == null || fragment == null) {
            throw new InvalidDataException("Dispositivo, distancia y fragmento son obligatorios");
        }
    }

    public DeviceReading withDistance(Distance newDistance) {
        return new DeviceReading(device, Objects.requireNonNull(newDistance), fragment);
    }

    public DeviceReading withFragment(MessageFragment newFragment) {
        return new DeviceReading(device, distance, Objects.requireNonNull(newFragment));
    }
}
