package com.centralcity.alchemy.infrastructure.adapter.in.web.dto;

import java.time.Instant;

public record ErrorResponse(int status, String error, String message, Instant timestamp) {
}
