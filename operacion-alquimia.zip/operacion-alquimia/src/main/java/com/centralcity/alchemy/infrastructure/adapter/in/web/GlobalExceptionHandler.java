package com.centralcity.alchemy.infrastructure.adapter.in.web;

import java.time.Instant;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.centralcity.alchemy.domain.exception.DeviceReadingAlreadyExistsException;
import com.centralcity.alchemy.domain.exception.DeviceReadingNotFoundException;
import com.centralcity.alchemy.domain.exception.DomainException;
import com.centralcity.alchemy.domain.exception.InsufficientDataException;
import com.centralcity.alchemy.domain.exception.InvalidDataException;
import com.centralcity.alchemy.domain.exception.MessageReconstructionException;
import com.centralcity.alchemy.domain.exception.UnknownDeviceException;
import com.centralcity.alchemy.infrastructure.adapter.in.web.dto.ErrorResponse;

/** Único lugar donde los errores de dominio se traducen a códigos HTTP. */
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler({ UnknownDeviceException.class, DeviceReadingNotFoundException.class })
    ResponseEntity<ErrorResponse> notFound(DomainException ex) {
        return build(HttpStatus.NOT_FOUND, ex.getMessage());
    }

    @ExceptionHandler(DeviceReadingAlreadyExistsException.class)
    ResponseEntity<ErrorResponse> conflict(DomainException ex) {
        return build(HttpStatus.CONFLICT, ex.getMessage());
    }

    @ExceptionHandler({ InsufficientDataException.class, MessageReconstructionException.class })
    ResponseEntity<ErrorResponse> unprocessable(DomainException ex) {
        return build(HttpStatus.UNPROCESSABLE_ENTITY, ex.getMessage());
    }

    @ExceptionHandler({ InvalidDataException.class, DomainException.class })
    ResponseEntity<ErrorResponse> badRequest(DomainException ex) {
        return build(HttpStatus.BAD_REQUEST, ex.getMessage());
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    ResponseEntity<ErrorResponse> unreadable(HttpMessageNotReadableException ex) {
        return build(HttpStatus.BAD_REQUEST, "Cuerpo de la solicitud ausente o con formato JSON/tipos inválidos");
    }

    private ResponseEntity<ErrorResponse> build(HttpStatus status, String message) {
        return ResponseEntity.status(status)
                .body(new ErrorResponse(status.value(), status.getReasonPhrase(), message, Instant.now()));
    }
}
