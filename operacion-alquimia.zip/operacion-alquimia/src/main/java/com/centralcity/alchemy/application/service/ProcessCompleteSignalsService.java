package com.centralcity.alchemy.application.service;

import java.util.List;

import com.centralcity.alchemy.application.port.in.ProcessCompleteSignalsUseCase;
import com.centralcity.alchemy.domain.exception.InvalidDataException;
import com.centralcity.alchemy.domain.model.AnalysisResult;
import com.centralcity.alchemy.domain.model.DeviceReading;
import com.centralcity.alchemy.domain.service.SignalAnalyzer;

public class ProcessCompleteSignalsService implements ProcessCompleteSignalsUseCase {

    private final SignalAnalyzer analyzer;

    public ProcessCompleteSignalsService(SignalAnalyzer analyzer) {
        this.analyzer = analyzer;
    }

    @Override
    public AnalysisResult process(List<ReadingData> readings) {
        if (readings == null || readings.isEmpty()) {
            throw new InvalidDataException("Se requiere la información de los tres dispositivos");
        }
        List<DeviceReading> domainReadings = readings.stream()
                .map(r -> {
                    if (r == null) {
                        throw new InvalidDataException("Hay una lectura nula en la solicitud");
                    }
                    return ReadingFactory.complete(r.device(), r.distance(), r.message());
                })
                .toList();
        return analyzer.analyze(domainReadings);
    }
}
