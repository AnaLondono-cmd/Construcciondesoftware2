package com.centralcity.alchemy.infrastructure.adapter.in.web.dto;

import java.util.List;

public record AnalysisRequest(List<ReadingRequest> readings) {
}
