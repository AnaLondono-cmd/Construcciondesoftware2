package com.centralcity.alchemy.application.port.in;

import java.util.List;

import com.centralcity.alchemy.domain.model.DeviceReading;

/** F3 (consulta). */
public interface QueryReadingsUseCase {
    List<DeviceReading> findAll();

    DeviceReading findByDevice(String device);
}
