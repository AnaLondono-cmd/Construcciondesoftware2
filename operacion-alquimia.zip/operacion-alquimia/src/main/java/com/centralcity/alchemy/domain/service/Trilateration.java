package com.centralcity.alchemy.domain.service;

import java.util.List;

import com.centralcity.alchemy.domain.exception.InvalidDataException;
import com.centralcity.alchemy.domain.model.DeviceReading;
import com.centralcity.alchemy.domain.model.Position;

/**
 * Trilateración con tres circunferencias. Restando la ecuación del primer círculo
 * a las otras dos se obtiene un sistema lineal 2x2 que se resuelve con Cramer.
 */
public class Trilateration {

    private static final double EPSILON = 1e-9;

    public Position locate(List<DeviceReading> readings) {
        if (readings.size() != 3) {
            throw new InvalidDataException("La trilateración requiere exactamente tres lecturas");
        }
        Position p1 = readings.get(0).device().position();
        Position p2 = readings.get(1).device().position();
        Position p3 = readings.get(2).device().position();
        double d1 = readings.get(0).distance().value();
        double d2 = readings.get(1).distance().value();
        double d3 = readings.get(2).distance().value();

        double a1 = 2 * (p2.x() - p1.x());
        double b1 = 2 * (p2.y() - p1.y());
        double c1 = square(d1) - square(d2) + square(p2.x()) - square(p1.x()) + square(p2.y()) - square(p1.y());

        double a2 = 2 * (p3.x() - p1.x());
        double b2 = 2 * (p3.y() - p1.y());
        double c2 = square(d1) - square(d3) + square(p3.x()) - square(p1.x()) + square(p3.y()) - square(p1.y());

        double det = a1 * b2 - a2 * b1;
        if (Math.abs(det) < EPSILON) {
            throw new InvalidDataException("Los dispositivos son colineales: no es posible trilaterar");
        }
        double x = (c1 * b2 - c2 * b1) / det;
        double y = (a1 * c2 - a2 * c1) / det;
        return new Position(round(x), round(y));
    }

    private static double square(double v) {
        return v * v;
    }

    private static double round(double v) {
        return Math.round(v * 100.0) / 100.0 + 0.0; // "+ 0.0" evita -0.0
    }
}
