package com.centralcity.alchemy.application.port.in;

import java.util.List;

import com.centralcity.alchemy.domain.model.DeviceReading;

/** F5: actualización parcial. Un campo null conserva su valor anterior. */
public interface UpdateReadingUseCase {
    record Command(String device, Double distance, List<String> message) {
    }

    DeviceReading update(Command command);
}
