package com.centralcity.alchemy.application.port.in;

import java.util.List;

import com.centralcity.alchemy.domain.model.DeviceReading;

/** F4: reemplazo completo. Distancia y fragmento son obligatorios. */
public interface ReplaceReadingUseCase {
    record Command(String device, Double distance, List<String> message) {
    }

    DeviceReading replace(Command command);
}
