package com.centralcity.alchemy.domain.model;

public record AnalysisResult(Position position, String message) {
}
