package com.centralcity.alchemy.application.port.in;

import java.util.List;

import com.centralcity.alchemy.domain.model.AnalysisResult;

/** F1: procesa la información completa de los tres dispositivos sin almacenarla. */
public interface ProcessCompleteSignalsUseCase {
    record ReadingData(String device, Double distance, List<String> message) {
    }

    AnalysisResult process(List<ReadingData> readings);
}
