package com.centralcity.alchemy.domain.exception;

/** Raíz de los errores de negocio. No conoce HTTP. */
public abstract class DomainException extends RuntimeException {
    protected DomainException(String message) {
        super(message);
    }
}
