package com.centralcity.alchemy.application.service;

import com.centralcity.alchemy.application.port.in.DeleteReadingUseCase;
import com.centralcity.alchemy.application.port.in.RegisterReadingUseCase;
import com.centralcity.alchemy.application.port.in.ReplaceReadingUseCase;
import com.centralcity.alchemy.application.port.in.UpdateReadingUseCase;
import com.centralcity.alchemy.application.port.out.DeviceReadingRepository;
import com.centralcity.alchemy.domain.exception.DeviceReadingAlreadyExistsException;
import com.centralcity.alchemy.domain.exception.DeviceReadingNotFoundException;
import com.centralcity.alchemy.domain.exception.InvalidDataException;
import com.centralcity.alchemy.domain.model.DeviceReading;
import com.centralcity.alchemy.domain.model.Distance;
import com.centralcity.alchemy.domain.model.MessageFragment;
import com.centralcity.alchemy.domain.model.SurveillanceDevice;

/**
 * Casos de uso de escritura (F2, F4, F5, F6). Los métodos son synchronized para que las
 * secuencias "leer → validar → guardar" sean atómicas ante peticiones concurrentes.
 */
public class ReadingCommandService
        implements RegisterReadingUseCase, ReplaceReadingUseCase, UpdateReadingUseCase, DeleteReadingUseCase {

    private final DeviceReadingRepository repository;

    public ReadingCommandService(DeviceReadingRepository repository) {
        this.repository = repository;
    }

    @Override
    public synchronized DeviceReading register(RegisterReadingUseCase.Command command) {
        DeviceReading reading = ReadingFactory.complete(command.device(), command.distance(), command.message());
        if (repository.findByDevice(reading.device()).isPresent()) {
            throw new DeviceReadingAlreadyExistsException(reading.device().code());
        }
        repository.save(reading);
        return reading;
    }

    @Override
    public synchronized DeviceReading replace(ReplaceReadingUseCase.Command command) {
        DeviceReading reading = ReadingFactory.complete(command.device(), command.distance(), command.message());
        if (repository.findByDevice(reading.device()).isEmpty()) {
            throw new DeviceReadingNotFoundException(reading.device().code());
        }
        repository.save(reading);
        return reading;
    }

    @Override
    public synchronized DeviceReading update(UpdateReadingUseCase.Command command) {
        SurveillanceDevice device = SurveillanceDevice.fromCode(command.device());
        if (command.distance() == null && command.message() == null) {
            throw new InvalidDataException("Debe indicar al menos la distancia o el fragmento del mensaje");
        }
        DeviceReading current = repository.findByDevice(device)
                .orElseThrow(() -> new DeviceReadingNotFoundException(device.code()));
        DeviceReading updated = current;
        if (command.distance() != null) {
            updated = updated.withDistance(new Distance(command.distance()));
        }
        if (command.message() != null) {
            updated = updated.withFragment(new MessageFragment(command.message()));
        }
        repository.save(updated);
        return updated;
    }

    @Override
    public synchronized void delete(String deviceCode) {
        SurveillanceDevice device = SurveillanceDevice.fromCode(deviceCode);
        if (!repository.deleteByDevice(device)) {
            throw new DeviceReadingNotFoundException(device.code());
        }
    }
}
