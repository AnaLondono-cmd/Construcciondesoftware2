package com.centralcity.alchemy.domain.model;

import java.util.Locale;

import com.centralcity.alchemy.domain.exception.UnknownDeviceException;

/** Los tres dispositivos de vigilancia con su posición fija en Central City. */
public enum SurveillanceDevice {
    STAR_LABS("star-labs", new Position(-500, -200)),
    CCPD("ccpd", new Position(100, -100)),
    STAR_SATELLITE("star-satellite", new Position(500, 100));

    private final String code;
    private final Position position;

    SurveillanceDevice(String code, Position position) {
        this.code = code;
        this.position = position;
    }

    public String code() {
        return code;
    }

    public Position position() {
        return position;
    }

    /** Acepta mayúsculas/minúsculas y guion bajo o guion medio (STAR_LABS, star-labs). */
    public static SurveillanceDevice fromCode(String raw) {
        if (raw == null || raw.isBlank()) {
            throw new UnknownDeviceException(raw);
        }
        String normalized = raw.trim().toLowerCase(Locale.ROOT).replace('_', '-');
        for (SurveillanceDevice device : values()) {
            if (device.code.equals(normalized)) {
                return device;
            }
        }
        throw new UnknownDeviceException(raw);
    }
}
