package com.centralcity.alchemy.domain.model;

public record Position(double x, double y) {
}
