package com.centralcity.alchemy.infrastructure.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.centralcity.alchemy.application.port.out.DeviceReadingRepository;
import com.centralcity.alchemy.application.service.ProcessCompleteSignalsService;
import com.centralcity.alchemy.application.service.ReadingCommandService;
import com.centralcity.alchemy.application.service.ReadingQueryService;
import com.centralcity.alchemy.domain.service.SignalAnalyzer;
import com.centralcity.alchemy.infrastructure.adapter.out.memory.InMemoryDeviceReadingRepository;

/** Composición: dominio y aplicación quedan libres de anotaciones de Spring. */
@Configuration
public class BeanConfig {

    @Bean
    DeviceReadingRepository deviceReadingRepository() {
        return new InMemoryDeviceReadingRepository();
    }

    @Bean
    SignalAnalyzer signalAnalyzer() {
        return new SignalAnalyzer();
    }

    @Bean
    ProcessCompleteSignalsService processCompleteSignalsService(SignalAnalyzer analyzer) {
        return new ProcessCompleteSignalsService(analyzer);
    }

    @Bean
    ReadingCommandService readingCommandService(DeviceReadingRepository repository) {
        return new ReadingCommandService(repository);
    }

    @Bean
    ReadingQueryService readingQueryService(DeviceReadingRepository repository, SignalAnalyzer analyzer) {
        return new ReadingQueryService(repository, analyzer);
    }
}
