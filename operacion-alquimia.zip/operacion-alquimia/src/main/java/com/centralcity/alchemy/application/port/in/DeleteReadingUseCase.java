package com.centralcity.alchemy.application.port.in;

/** F6: eliminación. */
public interface DeleteReadingUseCase {
    void delete(String device);
}
