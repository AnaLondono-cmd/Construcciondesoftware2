package com.centralcity.alchemy.application.port.in;

import java.util.List;

import com.centralcity.alchemy.domain.model.DeviceReading;

/** F2: registro individual. */
public interface RegisterReadingUseCase {
    record Command(String device, Double distance, List<String> message) {
    }

    DeviceReading register(Command command);
}
