package com.centralcity.alchemy.domain.exception;

public class DeviceReadingAlreadyExistsException extends DomainException {
    public DeviceReadingAlreadyExistsException(String code) {
        super("Ya existe información registrada para el dispositivo '" + code
                + "'. Use reemplazo (PUT) o actualización parcial (PATCH)");
    }
}
