package com.centralcity.alchemy.domain.exception;

public class UnknownDeviceException extends DomainException {
    public UnknownDeviceException(String device) {
        super("Dispositivo desconocido: '" + device + "'. Valores válidos: star-labs, ccpd, star-satellite");
    }
}
