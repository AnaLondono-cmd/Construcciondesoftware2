package com.centralcity.alchemy.infrastructure.adapter.in.web;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.centralcity.alchemy.application.port.in.DeleteReadingUseCase;
import com.centralcity.alchemy.application.port.in.ProcessAccumulatedUseCase;
import com.centralcity.alchemy.application.port.in.ProcessCompleteSignalsUseCase;
import com.centralcity.alchemy.application.port.in.QueryReadingsUseCase;
import com.centralcity.alchemy.application.port.in.RegisterReadingUseCase;
import com.centralcity.alchemy.application.port.in.ReplaceReadingUseCase;
import com.centralcity.alchemy.application.port.in.UpdateReadingUseCase;
import com.centralcity.alchemy.infrastructure.adapter.in.web.dto.AnalysisRequest;
import com.centralcity.alchemy.infrastructure.adapter.in.web.dto.AnalysisResponse;
import com.centralcity.alchemy.infrastructure.adapter.in.web.dto.ReadingDataRequest;
import com.centralcity.alchemy.infrastructure.adapter.in.web.dto.ReadingRequest;
import com.centralcity.alchemy.infrastructure.adapter.in.web.dto.ReadingResponse;

/** Adaptador de entrada HTTP. Solo traduce HTTP <-> casos de uso. */
@RestController
@RequestMapping("/api/v1")
public class AlchemyController {

    private final ProcessCompleteSignalsUseCase processComplete;
    private final RegisterReadingUseCase register;
    private final QueryReadingsUseCase query;
    private final ProcessAccumulatedUseCase processAccumulated;
    private final ReplaceReadingUseCase replace;
    private final UpdateReadingUseCase update;
    private final DeleteReadingUseCase delete;

    public AlchemyController(ProcessCompleteSignalsUseCase processComplete, RegisterReadingUseCase register,
            QueryReadingsUseCase query, ProcessAccumulatedUseCase processAccumulated, ReplaceReadingUseCase replace,
            UpdateReadingUseCase update, DeleteReadingUseCase delete) {
        this.processComplete = processComplete;
        this.register = register;
        this.query = query;
        this.processAccumulated = processAccumulated;
        this.replace = replace;
        this.update = update;
        this.delete = delete;
    }

    /** F1 */
    @PostMapping("/analysis")
    public AnalysisResponse processComplete(@RequestBody AnalysisRequest request) {
        List<ProcessCompleteSignalsUseCase.ReadingData> data = request.readings() == null ? null
                : request.readings().stream()
                        .map(r -> r == null ? null
                                : new ProcessCompleteSignalsUseCase.ReadingData(r.device(), r.distance(), r.message()))
                        .toList();
        return AnalysisResponse.from(processComplete.process(data));
    }

    /** F2 */
    @PostMapping("/readings")
    public ResponseEntity<ReadingResponse> register(@RequestBody ReadingRequest request) {
        ReadingResponse body = ReadingResponse.from(
                register.register(new RegisterReadingUseCase.Command(request.device(), request.distance(), request.message())));
        return ResponseEntity.created(URI.create("/api/v1/readings/" + body.device())).body(body);
    }

    /** F3 - consulta */
    @GetMapping("/readings")
    public List<ReadingResponse> findAll() {
        return query.findAll().stream().map(ReadingResponse::from).toList();
    }

    @GetMapping("/readings/{device}")
    public ReadingResponse findOne(@PathVariable String device) {
        return ReadingResponse.from(query.findByDevice(device));
    }

    /** F3 - procesamiento acumulado */
    @GetMapping("/analysis")
    public AnalysisResponse processAccumulated() {
        return AnalysisResponse.from(processAccumulated.process());
    }

    /** F4 */
    @PutMapping("/readings/{device}")
    public ReadingResponse replace(@PathVariable String device, @RequestBody ReadingDataRequest request) {
        return ReadingResponse.from(
                replace.replace(new ReplaceReadingUseCase.Command(device, request.distance(), request.message())));
    }

    /** F5 */
    @PatchMapping("/readings/{device}")
    public ReadingResponse update(@PathVariable String device, @RequestBody ReadingDataRequest request) {
        return ReadingResponse.from(
                update.update(new UpdateReadingUseCase.Command(device, request.distance(), request.message())));
    }

    /** F6 */
    @DeleteMapping("/readings/{device}")
    public ResponseEntity<Void> delete(@PathVariable String device) {
        delete.delete(device);
        return ResponseEntity.noContent().build();
    }
}
