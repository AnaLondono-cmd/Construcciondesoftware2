package com.centralcity.alchemy.domain.model;

import java.util.List;

import com.centralcity.alchemy.domain.exception.InvalidDataException;

/**
 * Fragmento de mensaje de un dispositivo. Las palabras vacías ("") representan
 * palabras no recibidas y se ignoran al reconstruir.
 */
public record MessageFragment(List<String> words) {
    public MessageFragment {
        if (words == null || words.isEmpty()) {
            throw new InvalidDataException("El fragmento del mensaje es obligatorio y no puede ser una lista vacía");
        }
        if (words.stream().anyMatch(w -> w == null)) {
            throw new InvalidDataException("El fragmento no puede contener elementos nulos (use \"\" para palabras no recibidas)");
        }
        words = List.copyOf(words);
    }
}
