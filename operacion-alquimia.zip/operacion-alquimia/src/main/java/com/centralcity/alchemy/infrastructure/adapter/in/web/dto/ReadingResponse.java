package com.centralcity.alchemy.infrastructure.adapter.in.web.dto;

import java.util.List;

import com.centralcity.alchemy.domain.model.DeviceReading;

public record ReadingResponse(String device, double distance, List<String> message) {
    public static ReadingResponse from(DeviceReading r) {
        return new ReadingResponse(r.device().code(), r.distance().value(), r.fragment().words());
    }
}
