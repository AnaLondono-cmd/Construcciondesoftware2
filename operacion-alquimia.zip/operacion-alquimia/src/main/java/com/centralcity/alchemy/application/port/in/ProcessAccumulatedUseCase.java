package com.centralcity.alchemy.application.port.in;

import com.centralcity.alchemy.domain.model.AnalysisResult;

/** F3 (procesamiento acumulado). */
public interface ProcessAccumulatedUseCase {
    AnalysisResult process();
}
