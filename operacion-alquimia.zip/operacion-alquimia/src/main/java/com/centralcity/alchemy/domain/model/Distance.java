package com.centralcity.alchemy.domain.model;

import com.centralcity.alchemy.domain.exception.InvalidDataException;

public record Distance(double value) {
    public Distance {
        if (Double.isNaN(value) || Double.isInfinite(value)) {
            throw new InvalidDataException("La distancia debe ser un número finito");
        }
        if (value < 0) {
            throw new InvalidDataException("La distancia no puede ser negativa");
        }
    }
}
