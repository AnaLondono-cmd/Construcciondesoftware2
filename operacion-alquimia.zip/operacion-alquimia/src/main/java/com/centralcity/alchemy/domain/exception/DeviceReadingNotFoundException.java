package com.centralcity.alchemy.domain.exception;

public class DeviceReadingNotFoundException extends DomainException {
    public DeviceReadingNotFoundException(String code) {
        super("No hay información registrada para el dispositivo '" + code + "'");
    }
}
