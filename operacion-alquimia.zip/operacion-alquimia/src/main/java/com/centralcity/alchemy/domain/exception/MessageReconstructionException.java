package com.centralcity.alchemy.domain.exception;

public class MessageReconstructionException extends DomainException {
    public MessageReconstructionException(String message) {
        super(message);
    }
}
