package com.centralcity.alchemy.domain.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import com.centralcity.alchemy.domain.exception.InsufficientDataException;
import com.centralcity.alchemy.domain.exception.InvalidDataException;
import com.centralcity.alchemy.domain.model.AnalysisResult;
import com.centralcity.alchemy.domain.model.DeviceReading;
import com.centralcity.alchemy.domain.model.MessageFragment;
import com.centralcity.alchemy.domain.model.SurveillanceDevice;

/** Servicio de dominio: exige los tres dispositivos y combina trilateración + reconstrucción. */
public class SignalAnalyzer {

    private final Trilateration trilateration = new Trilateration();
    private final MessageReconstructor reconstructor = new MessageReconstructor();

    public AnalysisResult analyze(Collection<DeviceReading> readings) {
        if (readings == null) {
            throw new InvalidDataException("Las lecturas son obligatorias");
        }
        Map<SurveillanceDevice, DeviceReading> byDevice = new EnumMap<>(SurveillanceDevice.class);
        for (DeviceReading reading : readings) {
            if (byDevice.put(reading.device(), reading) != null) {
                throw new InvalidDataException("Dispositivo repetido: " + reading.device().code());
            }
        }
        List<SurveillanceDevice> missing = new ArrayList<>();
        for (SurveillanceDevice device : SurveillanceDevice.values()) {
            if (!byDevice.containsKey(device)) {
                missing.add(device);
            }
        }
        if (!missing.isEmpty()) {
            throw new InsufficientDataException(missing);
        }
        List<DeviceReading> ordered = new ArrayList<>(byDevice.values()); // orden de declaración del enum
        List<MessageFragment> fragments = ordered.stream().map(DeviceReading::fragment).toList();
        return new AnalysisResult(trilateration.locate(ordered), reconstructor.reconstruct(fragments));
    }
}
