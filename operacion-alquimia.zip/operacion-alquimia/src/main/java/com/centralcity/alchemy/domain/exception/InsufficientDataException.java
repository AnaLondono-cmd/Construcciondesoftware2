package com.centralcity.alchemy.domain.exception;

import java.util.Collection;
import java.util.stream.Collectors;

import com.centralcity.alchemy.domain.model.SurveillanceDevice;

public class InsufficientDataException extends DomainException {
    public InsufficientDataException(Collection<SurveillanceDevice> missing) {
        super("No existen datos suficientes. Dispositivos faltantes: "
                + missing.stream().map(SurveillanceDevice::code).collect(Collectors.joining(", ")));
    }
}
