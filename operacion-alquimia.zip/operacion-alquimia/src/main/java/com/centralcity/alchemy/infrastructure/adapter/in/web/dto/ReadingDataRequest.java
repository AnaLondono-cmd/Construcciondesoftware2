package com.centralcity.alchemy.infrastructure.adapter.in.web.dto;

import java.util.List;

/** Cuerpo de PUT (ambos campos obligatorios) y PATCH (campos opcionales). */
public record ReadingDataRequest(Double distance, List<String> message) {
}
