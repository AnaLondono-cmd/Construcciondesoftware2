package com.centralcity.alchemy.application.service;

import java.util.List;

import com.centralcity.alchemy.domain.exception.InvalidDataException;
import com.centralcity.alchemy.domain.model.DeviceReading;
import com.centralcity.alchemy.domain.model.Distance;
import com.centralcity.alchemy.domain.model.MessageFragment;
import com.centralcity.alchemy.domain.model.SurveillanceDevice;

/** Convierte datos primitivos de los casos de uso en objetos de dominio validados. */
final class ReadingFactory {
    private ReadingFactory() {
    }

    static DeviceReading complete(String device, Double distance, List<String> message) {
        if (distance == null) {
            throw new InvalidDataException("La distancia es obligatoria");
        }
        if (message == null) {
            throw new InvalidDataException("El fragmento del mensaje es obligatorio");
        }
        return new DeviceReading(SurveillanceDevice.fromCode(device), new Distance(distance), new MessageFragment(message));
    }
}
