package com.centralcity.alchemy.domain.service;

import java.util.ArrayList;
import java.util.List;

import com.centralcity.alchemy.domain.exception.MessageReconstructionException;
import com.centralcity.alchemy.domain.model.MessageFragment;

/**
 * Reconstruye el mensaje original:
 * 1. Elimina el desfase: los fragmentos más largos se recortan por el inicio hasta igualar al más corto.
 * 2. Para cada posición toma la palabra no vacía (los "" se ignoran).
 * 3. Falla si una posición queda sin palabra o si dos fragmentos discrepan.
 */
public class MessageReconstructor {

    public String reconstruct(List<MessageFragment> fragments) {
        if (fragments.isEmpty()) {
            throw new MessageReconstructionException("No hay fragmentos para reconstruir el mensaje");
        }
        int length = fragments.stream().mapToInt(f -> f.words().size()).min().orElse(0);

        List<List<String>> aligned = new ArrayList<>();
        for (MessageFragment fragment : fragments) {
            List<String> words = fragment.words();
            aligned.add(words.subList(words.size() - length, words.size()));
        }

        List<String> result = new ArrayList<>();
        for (int i = 0; i < length; i++) {
            String chosen = null;
            for (List<String> words : aligned) {
                String word = words.get(i);
                if (word.isBlank()) {
                    continue;
                }
                if (chosen == null) {
                    chosen = word;
                } else if (!chosen.equals(word)) {
                    throw new MessageReconstructionException("Fragmentos contradictorios en la posición " + (i + 1)
                            + ": '" + chosen + "' vs '" + word + "'");
                }
            }
            if (chosen == null) {
                throw new MessageReconstructionException(
                        "No se pudo reconstruir la palabra en la posición " + (i + 1) + ": ningún dispositivo la recibió");
            }
            result.add(chosen);
        }
        return String.join(" ", result);
    }
}
