package com.centralcity.alchemy.domain;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.centralcity.alchemy.domain.exception.InsufficientDataException;
import com.centralcity.alchemy.domain.exception.InvalidDataException;
import com.centralcity.alchemy.domain.exception.MessageReconstructionException;
import com.centralcity.alchemy.domain.model.AnalysisResult;
import com.centralcity.alchemy.domain.model.DeviceReading;
import com.centralcity.alchemy.domain.model.Distance;
import com.centralcity.alchemy.domain.model.MessageFragment;
import com.centralcity.alchemy.domain.model.Position;
import com.centralcity.alchemy.domain.model.SurveillanceDevice;
import com.centralcity.alchemy.domain.service.SignalAnalyzer;

class SignalAnalyzerTest {

    private final SignalAnalyzer analyzer = new SignalAnalyzer();

    private static DeviceReading reading(SurveillanceDevice d, Position lab, String... words) {
        double dist = Math.hypot(lab.x() - d.position().x(), lab.y() - d.position().y());
        return new DeviceReading(d, new Distance(dist), new MessageFragment(List.of(words)));
    }

    @Test
    void locatesLaboratoryAndRebuildsMessage() {
        Position lab = new Position(-100, 250);
        AnalysisResult r = analyzer.analyze(List.of(
                reading(SurveillanceDevice.STAR_SATELLITE, lab, "este", "es", "", "mensaje"),
                reading(SurveillanceDevice.STAR_LABS, lab, "este", "", "un", "mensaje"),
                reading(SurveillanceDevice.CCPD, lab, "", "es", "un", "")));
        assertEquals(-100.0, r.position().x(), 0.01);
        assertEquals(250.0, r.position().y(), 0.01);
        assertEquals("este es un mensaje", r.message());
    }

    @Test
    void removesLagFromLongerFragments() {
        Position lab = new Position(0, 0);
        AnalysisResult r = analyzer.analyze(List.of(
                reading(SurveillanceDevice.STAR_LABS, lab, "", "este", "es", "", "mensaje"),
                reading(SurveillanceDevice.CCPD, lab, "este", "", "un", "mensaje"),
                reading(SurveillanceDevice.STAR_SATELLITE, lab, "", "es", "un", "")));
        assertEquals("este es un mensaje", r.message());
    }

    @Test
    void failsWithoutAllDevices() {
        Position lab = new Position(0, 0);
        assertThrows(InsufficientDataException.class, () -> analyzer.analyze(List.of(
                reading(SurveillanceDevice.STAR_LABS, lab, "a"),
                reading(SurveillanceDevice.CCPD, lab, "a"))));
    }

    @Test
    void failsOnDuplicatedDevice() {
        Position lab = new Position(0, 0);
        assertThrows(InvalidDataException.class, () -> analyzer.analyze(List.of(
                reading(SurveillanceDevice.STAR_LABS, lab, "a"),
                reading(SurveillanceDevice.STAR_LABS, lab, "a"),
                reading(SurveillanceDevice.CCPD, lab, "a"))));
    }

    @Test
    void failsWhenAWordIsMissingEverywhere() {
        Position lab = new Position(0, 0);
        assertThrows(MessageReconstructionException.class, () -> analyzer.analyze(List.of(
                reading(SurveillanceDevice.STAR_LABS, lab, "a", ""),
                reading(SurveillanceDevice.CCPD, lab, "a", ""),
                reading(SurveillanceDevice.STAR_SATELLITE, lab, "a", ""))));
    }

    @Test
    void failsOnContradictoryWords() {
        Position lab = new Position(0, 0);
        assertThrows(MessageReconstructionException.class, () -> analyzer.analyze(List.of(
                reading(SurveillanceDevice.STAR_LABS, lab, "hola"),
                reading(SurveillanceDevice.CCPD, lab, "adios"),
                reading(SurveillanceDevice.STAR_SATELLITE, lab, ""))));
    }

    @Test
    void rejectsInvalidValues() {
        assertThrows(InvalidDataException.class, () -> new Distance(-1));
        assertThrows(InvalidDataException.class, () -> new Distance(Double.NaN));
        assertThrows(InvalidDataException.class, () -> new MessageFragment(List.of()));
    }
}
