package com.centralcity.alchemy.infrastructure;

import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasSize;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

/** Laboratorio en (100, 200): distancias 721.1103 / 300 / 412.3106. */
@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = ClassMode.BEFORE_EACH_TEST_METHOD)
class AlchemyApiTest {

    @Autowired
    MockMvc mvc;

    private ResultActions send(org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder b, String json)
            throws Exception {
        return mvc.perform(b.contentType(MediaType.APPLICATION_JSON).content(json));
    }

    private void registerAll() throws Exception {
        send(post("/api/v1/readings"), "{\"device\":\"ccpd\",\"distance\":300,\"message\":[\"\",\"es\",\"un\",\"\"]}")
                .andExpect(status().isCreated());
        send(post("/api/v1/readings"),
                "{\"device\":\"star-satellite\",\"distance\":412.3106,\"message\":[\"este\",\"es\",\"\",\"mensaje\"]}")
                .andExpect(status().isCreated());
        send(post("/api/v1/readings"),
                "{\"device\":\"star-labs\",\"distance\":721.1103,\"message\":[\"este\",\"\",\"un\",\"mensaje\"]}")
                .andExpect(status().isCreated());
    }

    @Test
    void f1_processesCompleteInformation() throws Exception {
        String body = "{\"readings\":["
                + "{\"device\":\"star-labs\",\"distance\":721.1103,\"message\":[\"este\",\"\",\"un\",\"mensaje\"]},"
                + "{\"device\":\"ccpd\",\"distance\":300,\"message\":[\"\",\"es\",\"un\",\"\"]},"
                + "{\"device\":\"star-satellite\",\"distance\":412.3106,\"message\":[\"este\",\"es\",\"\",\"mensaje\"]}]}";
        send(post("/api/v1/analysis"), body).andExpect(status().isOk())
                .andExpect(jsonPath("$.position.x", closeTo(100.0, 0.05)))
                .andExpect(jsonPath("$.position.y", closeTo(200.0, 0.05)))
                .andExpect(jsonPath("$.message").value("este es un mensaje"));
    }

    @Test
    void f2_f3_registerInAnyOrderThenProcessAccumulated() throws Exception {
        send(post("/api/v1/readings"), "{\"device\":\"ccpd\",\"distance\":300,\"message\":[\"es\"]}")
                .andExpect(status().isCreated());
        mvc.perform(get("/api/v1/analysis")).andExpect(status().isUnprocessableEntity());
        send(post("/api/v1/readings"), "{\"device\":\"ccpd\",\"distance\":1,\"message\":[\"es\"]}")
                .andExpect(status().isConflict());
        mvc.perform(get("/api/v1/readings")).andExpect(jsonPath("$", hasSize(1)));

        mvc.perform(delete("/api/v1/readings/ccpd")).andExpect(status().isNoContent());
        registerAll();
        mvc.perform(get("/api/v1/readings")).andExpect(jsonPath("$", hasSize(3)));
        mvc.perform(get("/api/v1/analysis")).andExpect(status().isOk())
                .andExpect(jsonPath("$.position.x", closeTo(100.0, 0.05)))
                .andExpect(jsonPath("$.message").value("este es un mensaje"));
    }

    @Test
    void f4_replaceDoesNotTouchOtherDevices() throws Exception {
        registerAll();
        send(put("/api/v1/readings/ccpd"), "{\"distance\":10,\"message\":[\"x\"]}").andExpect(status().isOk())
                .andExpect(jsonPath("$.distance").value(10.0)).andExpect(jsonPath("$.message", contains("x")));
        mvc.perform(get("/api/v1/readings/star-labs")).andExpect(jsonPath("$.distance").value(721.1103));
        send(put("/api/v1/readings/ccpd"), "{\"distance\":10}").andExpect(status().isBadRequest());
    }

    @Test
    void f5_partialUpdateKeepsOmittedFields() throws Exception {
        registerAll();
        send(patch("/api/v1/readings/ccpd"), "{\"distance\":299.5}").andExpect(status().isOk())
                .andExpect(jsonPath("$.distance").value(299.5))
                .andExpect(jsonPath("$.message", contains("", "es", "un", "")));
        send(patch("/api/v1/readings/ccpd"), "{\"message\":[\"a\",\"b\"]}").andExpect(status().isOk())
                .andExpect(jsonPath("$.distance").value(299.5)).andExpect(jsonPath("$.message", contains("a", "b")));
        send(patch("/api/v1/readings/ccpd"), "{}").andExpect(status().isBadRequest());
    }

    @Test
    void f6_deleteAffectsOnlyThatDevice() throws Exception {
        registerAll();
        mvc.perform(delete("/api/v1/readings/ccpd")).andExpect(status().isNoContent());
        mvc.perform(get("/api/v1/readings/ccpd")).andExpect(status().isNotFound());
        mvc.perform(get("/api/v1/readings")).andExpect(jsonPath("$", hasSize(2)));
        mvc.perform(delete("/api/v1/readings/ccpd")).andExpect(status().isNotFound());
    }

    @Test
    void errors_unknownDeviceAndInvalidData() throws Exception {
        mvc.perform(get("/api/v1/readings/batcueva")).andExpect(status().isNotFound());
        send(post("/api/v1/readings"), "{\"device\":\"ccpd\",\"distance\":-5,\"message\":[\"a\"]}")
                .andExpect(status().isBadRequest());
        send(post("/api/v1/readings"), "{\"device\":\"ccpd\",\"distance\":\"abc\",\"message\":[\"a\"]}")
                .andExpect(status().isBadRequest());
        send(put("/api/v1/readings/ccpd"), "{\"distance\":1,\"message\":[\"a\"]}").andExpect(status().isNotFound());
    }
}
