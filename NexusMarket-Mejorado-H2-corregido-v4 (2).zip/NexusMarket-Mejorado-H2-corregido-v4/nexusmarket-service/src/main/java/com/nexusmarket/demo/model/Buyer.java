package com.nexusmarket.demo.model;
import jakarta.persistence.*;
@Entity(name="DemoBuyer") @Table(name="demo_buyers") public class Buyer {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(nullable=false,unique=true) public String username;
 @Column(nullable=false) public String fullName;
 @Column(nullable=false,unique=true) public String email;
 @Column(nullable=false) public String address;
 public String status="ACTIVE";
 public Buyer(){}
 public Buyer(String u,String n,String e,String a){username=u;fullName=n;email=e;address=a;}
}
