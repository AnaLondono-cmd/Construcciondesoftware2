package com.nexusmarket.demo.model;
import jakarta.persistence.*;import java.time.Instant;
@Entity(name="DemoShipment") @Table(name="demo_shipments") public class Shipment {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @OneToOne(optional=false) public Purchase purchase;
 public String status="PENDING"; public String trackingCode; public Instant updatedAt=Instant.now();
 public Shipment(){} public Shipment(Purchase p){purchase=p;}
}
