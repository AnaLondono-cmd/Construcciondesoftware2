package com.nexusmarket.demo.model;
import jakarta.persistence.*;import java.math.BigDecimal;import java.time.Instant;
@Entity(name="DemoInvoice") @Table(name="demo_invoices") public class Invoice {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @OneToOne(optional=false) public Purchase purchase;
 @Column(nullable=false,unique=true) public String invoiceNumber;
 @Column(nullable=false,precision=12,scale=2) public BigDecimal subtotal;
 @Column(nullable=false,precision=12,scale=2) public BigDecimal tax;
 @Column(nullable=false,precision=12,scale=2) public BigDecimal total;
 public String status="ISSUED";public Instant issuedAt=Instant.now();
 public Invoice(){}
}
