package com.nexusmarket.demo.repo;

import com.nexusmarket.demo.model.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface DemoInvoiceRepository extends JpaRepository<Invoice, Long> {
    Optional<Invoice> findByPurchase_Id(Long purchaseId);
}
