package com.nexusmarket.demo.repo;

import com.nexusmarket.demo.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DemoProductRepository extends JpaRepository<Product, Long> {}
