package com.nexusmarket.demo.repo;

import com.nexusmarket.demo.model.Shipment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DemoShipmentRepository extends JpaRepository<Shipment, Long> {}
