package com.nexusmarket.demo.model;
import jakarta.persistence.*;import java.math.BigDecimal;import java.time.Instant;import java.util.*;
@Entity(name="DemoPurchase") @Table(name="demo_purchases") public class Purchase {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) public Buyer buyer;
 @Column(nullable=false) public String status="PAID";
 @Column(nullable=false,precision=12,scale=2) public BigDecimal total=BigDecimal.ZERO;
 public String paymentReference="SIMULATED-APPROVAL";
 public Instant createdAt=Instant.now();
 @OneToMany(mappedBy="purchase",cascade=CascadeType.ALL,orphanRemoval=true,fetch=FetchType.EAGER) public List<PurchaseLine> lines=new ArrayList<>();
 public Purchase(){}
}
