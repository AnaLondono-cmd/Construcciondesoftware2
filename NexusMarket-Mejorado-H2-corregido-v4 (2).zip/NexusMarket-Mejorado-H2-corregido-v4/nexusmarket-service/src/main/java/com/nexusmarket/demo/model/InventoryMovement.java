package com.nexusmarket.demo.model;
import jakarta.persistence.*;import java.time.Instant;
@Entity(name="DemoInventoryMovement") @Table(name="demo_inventory_movements") public class InventoryMovement {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) public Product product; @ManyToOne(optional=false) public Seller seller;
 public String type; public int quantity; public String reference; public Instant createdAt=Instant.now();
 public InventoryMovement(){} public InventoryMovement(Product p,Seller s,String t,int q,String r){product=p;seller=s;type=t;quantity=q;reference=r;}
}
