package com.nexusmarket.demo.model;
import jakarta.persistence.*;import java.math.BigDecimal;
@Entity(name="DemoProduct") @Table(name="demo_products") public class Product {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(nullable=false) public String name;
 @Column(nullable=false) public String type; // PHYSICAL or DIGITAL
 @Column(nullable=false,precision=12,scale=2) public BigDecimal price;
 @ManyToOne(optional=false) public Seller seller;
 public String status="PUBLISHED";
 public Product(){} public Product(String n,String t,BigDecimal p,Seller s){name=n;type=t;price=p;seller=s;}
}
