package com.nexusmarket.demo.model;
import jakarta.persistence.*;import com.fasterxml.jackson.annotation.JsonIgnore;import java.math.BigDecimal;import java.time.Instant;
@Entity(name="DemoReturnCase") @Table(name="demo_returns") public class ReturnCase {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @JsonIgnore @ManyToOne(optional=false) public Purchase purchase;
 @ManyToOne(optional=false) public PurchaseLine purchaseLine;
 @ManyToOne(optional=false) public Buyer buyer;
 @ManyToOne(optional=false) public Seller seller;
 public int quantity; public String reason; public String status="REQUESTED";
 @Column(precision=12,scale=2) public BigDecimal refundAmount=BigDecimal.ZERO;
 public Instant createdAt=Instant.now();
 public ReturnCase(){}
}
