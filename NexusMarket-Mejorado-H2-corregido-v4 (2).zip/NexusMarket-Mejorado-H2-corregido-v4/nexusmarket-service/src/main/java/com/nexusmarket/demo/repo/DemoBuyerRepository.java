package com.nexusmarket.demo.repo;

import com.nexusmarket.demo.model.Buyer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DemoBuyerRepository extends JpaRepository<Buyer, Long> {}
