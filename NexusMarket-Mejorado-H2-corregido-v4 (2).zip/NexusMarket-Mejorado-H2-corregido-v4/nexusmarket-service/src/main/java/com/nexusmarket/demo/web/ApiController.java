package com.nexusmarket.demo.web;
import com.nexusmarket.demo.model.*;import com.nexusmarket.demo.service.MarketplaceService;import org.springframework.security.access.prepost.PreAuthorize;import org.springframework.security.core.Authentication;import org.springframework.web.bind.annotation.*;import jakarta.validation.Valid;import java.util.*;
@RestController @RequestMapping("/api") public class ApiController {
 private final MarketplaceService svc;

public ApiController(MarketplaceService svc) {
    this.svc = svc;
}
 @GetMapping("/health") public Object health(){return svc.health();}
 @GetMapping("/buyers") @PreAuthorize("hasAnyRole('ADMIN','SUPERVISOR')") public List<Buyer> buyers(){return svc.buyers();}
 @PostMapping("/buyers") @PreAuthorize("hasRole('ADMIN')") public Buyer createBuyer(@RequestBody Map<String,Object>x){return svc.createBuyer(x);}
 @GetMapping("/products") public List<Product> products(){return svc.products();}
 @PostMapping("/products") @PreAuthorize("hasRole('SELLER')") public Product createProduct(Authentication a,@RequestBody Map<String,Object>x){return svc.createProduct(a.getName(),x);}
 @GetMapping("/inventory/{productId}") @PreAuthorize("hasAnyRole('SELLER','ADMIN','SUPERVISOR','LOGISTICS_OPERATOR')") public Stock stock(Authentication a,@PathVariable Long productId){boolean seller=a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_SELLER"));return svc.stockFor(a.getName(),seller,productId);}
 @PostMapping("/inventory/{productId}/restock") @PreAuthorize("hasRole('SELLER')") public Stock restock(Authentication a,@PathVariable Long productId,@RequestBody Map<String,Integer>x){return svc.adjustStock(a.getName(),productId,x.getOrDefault("quantity",0));}
 @GetMapping("/cart") @PreAuthorize("hasRole('BUYER')") public Object cart(Authentication a){return svc.cart(a.getName());}
 @PostMapping("/cart/items") @PreAuthorize("hasRole('BUYER')") public Object addCart(Authentication a,@RequestBody Map<String,Object>x){return svc.addCart(a.getName(),Long.valueOf(x.get("productId").toString()),Integer.parseInt(x.get("quantity").toString()));}
 @PostMapping("/checkout") @PreAuthorize("hasRole('BUYER')") public Purchase checkout(Authentication a){return svc.checkout(a.getName());}
 @GetMapping("/invoices/{orderId}") @PreAuthorize("hasAnyRole('BUYER','ADMIN','SUPERVISOR')") public Invoice invoice(Authentication a,@PathVariable Long orderId){boolean privileged=!a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_BUYER"));svc.orderFor(a.getName(),privileged,orderId);return svc.invoice(orderId);}
 @GetMapping("/orders") @PreAuthorize("hasAnyRole('BUYER','ADMIN','SUPERVISOR','LOGISTICS_OPERATOR')") public List<Purchase> orders(Authentication a){return svc.ordersFor(a.getName(),!a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_BUYER")));}
 @GetMapping("/orders/{id}") @PreAuthorize("hasAnyRole('BUYER','ADMIN','SUPERVISOR','LOGISTICS_OPERATOR')") public Purchase order(Authentication a,@PathVariable Long id){return svc.orderFor(a.getName(),!a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_BUYER")),id);}
 @PostMapping("/orders/{id}/dispatch") @PreAuthorize("hasRole('LOGISTICS_OPERATOR')") public Shipment dispatch(@PathVariable Long id){return svc.ship(id);}
 @PostMapping("/orders/{id}/deliver") @PreAuthorize("hasRole('LOGISTICS_OPERATOR')") public Shipment deliver(@PathVariable Long id){return svc.deliver(id);}
 @GetMapping("/shipments/{orderId}") @PreAuthorize("hasAnyRole('BUYER','ADMIN','SUPERVISOR','LOGISTICS_OPERATOR')") public Shipment shipment(Authentication a,@PathVariable Long orderId){return svc.shipmentFor(a.getName(),!a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_BUYER")),orderId);}
 @PostMapping("/orders/{orderId}/returns") @PreAuthorize("hasRole('BUYER')") public ReturnCase requestReturn(Authentication a,@PathVariable Long orderId,@RequestBody Map<String,Object>x){return svc.requestReturn(a.getName(),orderId,Long.valueOf(x.get("orderLineId").toString()),Integer.parseInt(x.get("quantity").toString()),Objects.toString(x.get("reason"),"Sin especificar"));}
 @GetMapping("/my/returns") @PreAuthorize("hasRole('BUYER')") public Object myReturns(Authentication a){return svc.buyerReturns(a.getName());}
 @GetMapping("/returns") @PreAuthorize("hasAnyRole('ADMIN','SUPERVISOR')") public List<ReturnCase> returns(){return svc.returnCases();}
 @PostMapping("/returns/{id}/approve") @PreAuthorize("hasRole('ADMIN')") public ReturnCase approve(@PathVariable Long id){return svc.approveReturn(id);}
 @PostMapping("/returns/{id}/refund") @PreAuthorize("hasRole('ADMIN')") public ReturnCase refund(@PathVariable Long id){return svc.refund(id);}
 @GetMapping("/reports/sales") @PreAuthorize("hasAnyRole('SELLER','SUPERVISOR','ADMIN')") public Object sales(Authentication a){return a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_SELLER"))?svc.sellerSales(a.getName()):svc.orders();}
 @GetMapping("/reports/inventory") @PreAuthorize("hasAnyRole('SELLER','SUPERVISOR','ADMIN')") public Object inventory(Authentication a){return a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_SELLER"))?svc.reportInventory(a.getName()):svc.reportInventoryAll();}
 @GetMapping("/reports/movements") @PreAuthorize("hasAnyRole('SELLER','SUPERVISOR','ADMIN')") public Object movements(Authentication a){return a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_SELLER"))?svc.reportMovements(a.getName()):svc.allMovements();}
 @GetMapping("/reports/returns") @PreAuthorize("hasAnyRole('SELLER','SUPERVISOR','ADMIN')") public Object reportReturns(Authentication a){return a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_SELLER"))?svc.reportReturns(a.getName()):svc.returnCases();}
 @GetMapping("/reports/dashboard") @PreAuthorize("hasAnyRole('SELLER','SUPERVISOR','ADMIN')") public Object dashboard(Authentication a){if(a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_SELLER")))return svc.dashboard(a.getName());return Map.of("sales",svc.orders(),"returns",svc.returnCases(),"inventory",svc.reportInventoryAll(),"inventoryMovements",svc.allMovements(),"products",svc.products());}
}
